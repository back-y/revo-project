	<div id="<?php echo 'latest_review_' .rand().time(); ?>" class="responsive-slider sw-latest-review loading <?php echo esc_attr( $el_class ); ?>" data-lg="<?php echo esc_attr( $columns ); ?>" data-md="<?php echo esc_attr( $columns1 ); ?>" data-sm="<?php echo esc_attr( $columns2 ); ?>" data-xs="<?php echo esc_attr( $columns3 ); ?>" data-mobile="<?php echo esc_attr( $columns4 ); ?>" data-speed="<?php echo esc_attr( $speed ); ?>" data-scroll="<?php echo esc_attr( $scroll ); ?>" data-interval="<?php echo esc_attr( $interval ); ?>"  data-autoplay="<?php echo esc_attr( $autoplay ); ?>">
		<div class="resp-slider-container">
			<div class="slider responsive">	
				<?php 
				$comments = get_comments( array( 'orderby' => 'comment_date', 'order' => 'DESC', 'post_type' => 'product', 'status' => 'approve', 'number' => $numberposts ) );
				foreach( $comments as $key => $comment ) {
					$item_review = get_comment_meta( $comment->comment_ID, 'rating', true );
					?>
					<div class="item item-comment">
						<div class="item-content-top">
							<h4><?php echo esc_html( $comment->comment_author ); ?></h4>
							<div class="item-revivew" >
								<span style="width:<?php echo esc_attr( 17*intval( $item_review ) . 'px' ); ?>"></span>
							</div>
						</div>				
						<div class="item-content">
							<?php echo wp_trim_words( $comment->comment_content, $length, '...' ); ?> 
						</div>
						<div class="item-post">
							<?php 
							$comment_post = '<a href="'. get_permalink( $comment->comment_post_ID ) .'"> '. get_the_title( $comment->comment_post_ID ) .'</a>';
							echo sprintf( __( 'On: %s', 'sw_woocommerce' ), $comment_post ); 
							?>						
						</div>	
						<div class="item-date">
							<?php $post_time = strtotime( get_comment_date( get_option( 'date_format' ), $comment->comment_ID ) ); ?>
							<?php echo sprintf( __( 'Post %s ago', 'sw_woocommerce' ), human_time_diff( $post_time, current_time('timestamp') ) ); ?>
						</div>
					</div>
					<?php 
				}
				?>
			</div>
		</div>
	</div>